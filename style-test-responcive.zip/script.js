const carouselList = document.querySelector('.carousel__list');
const carouselItems = document.querySelectorAll('.carousel__item');
const elems = Array.from(carouselItems);
const prevButton = document.querySelector('.carousel__button--prev');
const nextButton = document.querySelector('.carousel__button--next');
const indicators = document.querySelectorAll('.indicator');

carouselList.addEventListener('click', function (event) {
  var newActive = event.target.closest('.carousel__item'); // Get the closest carousel item

  if (!newActive || newActive.classList.contains('carousel__item_active')) {
    return;
  }

  update(newActive);
});

prevButton.addEventListener('click', function () {
  const current = elems.find((elem) => parseInt(elem.dataset.pos) === 0);
  const newActivePos = (parseInt(current.dataset.pos) - 1 + elems.length) % elems.length - Math.floor(elems.length / 1);
  const newActive = elems.find((elem) => parseInt(elem.dataset.pos) === newActivePos);

  update(newActive);
});

nextButton.addEventListener('click', function () {
  const current = elems.find((elem) => parseInt(elem.dataset.pos) === 0);
  const newActivePos = (parseInt(current.dataset.pos) + 1) % elems.length;
  const newActive = elems.find((elem) => parseInt(elem.dataset.pos) === newActivePos);

  update(newActive);
});

indicators.forEach((indicator, index) => {
  indicator.addEventListener('click', function () {
    const newActive = elems[index];
    update(newActive);
  });
});

const update = function (newActive) {
  const newActivePos = parseInt(newActive.dataset.pos);

  const current = elems.find((elem) => parseInt(elem.dataset.pos) === 0);
  const prev = elems.find((elem) => parseInt(elem.dataset.pos) === -1);
  const next = elems.find((elem) => parseInt(elem.dataset.pos) === 1);
  const first = elems.find((elem) => parseInt(elem.dataset.pos) === -2);
  const last = elems.find((elem) => parseInt(elem.dataset.pos) === 2);
  const three = elems.find((elem) => parseInt(elem.dataset.pos) === 3);
  const four = elems.find((elem) => parseInt(elem.dataset.pos) === -3);
  const six = elems.find((elem) => parseInt(elem.dataset.pos) === -4);
  const seven = elems.find((elem) => parseInt(elem.dataset.pos) === 4);

  current.classList.remove('carousel__item_active');
  newActive.classList.add('carousel__item_active');

  [current, prev, next, first, last, three, four, six, seven].forEach(item => {
    var itemPos = parseInt(item.dataset.pos);
    item.dataset.pos = getPos(itemPos, newActivePos);
  });

  updateIndicators(newActivePos);
};

const updateIndicators = function (newActivePos) {
  indicators.forEach((indicator, index) => {
    indicator.classList.remove('indicator_active'); // Remove active class from all first
    if (index === newActivePos % indicators.length) {
      console.log(newActivePos) // Use modulo to handle wrapping
      indicator.classList.add('indicator_active');
    }
  });
};

const getPos = function (current, active) {
  const totalItems = elems.length;
  const diff = current - active;

  if (Math.abs(diff) > totalItems / 2) {
    return diff > 0 ? diff - totalItems : diff + totalItems;
  }

  return diff;
}
