var banner = document.getElementById('banner');
var del = 0;
var t;

enablerInitHandler = function(e) {
	if(Enabler.isVisible()) {
		startAnim();
	} else {
		startAnim();
//		Enabler.addEventListener(studio.events.StudioEvent.VISIBLE, startAnim);
	} 
};

startAnim = function(e) {
	//Assign All the elements to the element on the page	
	var bgExit = document.getElementById('bgExit');
	//Add listeners
	addListeners();
	var introTimeline = new TimelineMax({

        });
	
	introTimeline
	    .from("#cta", 5, { scale: 0, opacity: 0, ease: Back.easeInOut }, del += 0)
	    .to("#cta", 5, { scale: 1.2, opacity: 1, ease: Back.easeInOut }, del += 0)
	    .to("#cta", 5, { scale: 1,  ease: Back.easeInOut }, del += 0)	
		
		.from("#cta1", 3, { scale: 0, opacity: 0, ease: Back.easeInOut }, del += 0)
	    .to("#cta1", 3, { scale: 1.2, opacity: 1, ease: Back.easeInOut }, del += 0)
	    .to("#cta1", 3, { scale: 1,  ease: Back.easeInOut }, del += 0)

		.to("#logo1", 2, { bottom:635, ease: Power4.easeOut }, del += 1)

		.to("#offer", 3, { bottom:450, ease: Power4.easeOut }, del += 0)
	    .to("#offer1", 3, { bottom:335, ease: Power4.easeOut }, del += 0)

		.from("#logoblack", 0.7, { scale: 1, opacity: 1, ease: Back.easeInOut }, del += 0)
	    .to("#logoblack", 0.7, { scale: 0.3, opacity: 0, ease: Back.easeInOut }, del += 0)
		.to("#logoblack", 0.7, { scale: 0,  ease: Back.easeInOut }, del += 0)
		//Frame 1
		//.to("#banner", 0.5, { opacity: 1, ease: Power2.easeOut }, del += 0.2)
		//.to("#logo", 0.5, { opacity: 1, ease: Power2.easeOut }, del += 0)
		.to("#headline", 1, { opacity: 1, ease: Power4.easeOut }, del += 0.5)
		//.from("#packshot", 0.5, { scale: 0, opacity: 0, ease: Power2.easeOut }, del += 0.5)
		//.from("#disclaimer", 0.5, { opacity: 0, ease: Power2.easeOut }, del += 0.8)
		
        .to("#branding1", 0.7, { opacity: 1,top:2, ease: Power4.easeOut }, del += 2)
	    .to("#branding2", 0.7, { opacity: 1,bottom:0, ease: Power4.easeOut }, del += 0.7)
		.to("#branding3", 0.7, { opacity: 1,bottom:0, ease: Power4.easeOut }, del += 0.7)
		.to("#offernew", 0.7, { right:0, ease: Power4.easeOut }, del += 0.7)
	    .to("#offernew1", 0.7, { left:0, ease: Power4.easeOut }, del += 0.7)

		//Frame 2
		//.to("#frame_2__text", 0.5, { opacity: 0, ease: Power2.easeOut }, del += 2.0)
		.from("#ctanew", 0.1, { scale: 0, opacity: 0, ease: Back.easeInOut }, del += 0)
	    .to("#ctanew", 0.1, { scale: 1, opacity: 1, ease: Back.easeInOut }, del += 0)
	    .to("#ctanew", 0.1, { scale: 1,  ease: Back.easeInOut }, del += 0)

		// Frame 3
		.to("#branding11", 0.7, { opacity: 1,top:2, ease: Power4.easeOut }, del += 2)
	    .to("#branding22", 0.7, { opacity: 1,bottom:0, ease: Power4.easeOut }, del += 0.7)
		.to("#branding33", 0.7, { opacity: 1,bottom:0, ease: Power4.easeOut }, del += 0.7)
		.to("#offernew1new", 0.7, { right:0, ease: Power4.easeOut }, del += 0.7)
	    .to("#offernew11", 0.7, { left:0, ease: Power4.easeOut }, del += 0.7)

		// Frame 4
		.to("#branding111", 0.7, { opacity: 1,top:2, ease: Power4.easeOut }, del += 2)
	    .to("#branding222", 0.7, { opacity: 1,bottom:-4, ease: Power4.easeOut }, del += 0.7)
		.to("#branding333", 0.7, { opacity: 1,bottom:-4, ease: Power4.easeOut }, del += 0.7)
		.to("#offernew1new1", 0.7, { right:0, ease: Power4.easeOut }, del += 0.7)
	    .to("#offernew111", 0.7, { left:0, ease: Power4.easeOut }, del += 0.7)

		// Frame 5
		.to("#branding1111", 0.7, { opacity: 1,top:2, ease: Power4.easeOut }, del += 2)
	    .to("#branding2222", 0.7, { opacity: 1,bottom:-4, ease: Power4.easeOut }, del += 0.7)
		.to("#branding3333", 0.7, { opacity: 1,bottom:-4, ease: Power4.easeOut }, del += 0.7)
		.to("#offernew1new11", 0.7, { right:0, ease: Power4.easeOut }, del += 0.7)
	    .to("#offernew1111", 0.7, { left:0, ease: Power4.easeOut }, del += 0.7)

		//.to("#frame_1__text", 0.5, { opacity: 0, ease: Power2.easeOut }, del += 0.8)
		.to("#headline", 0.7, { opacity: 0, ease: Power2.easeOut}, del += 2)
        
        .to("#offer2", 0.6, { left:0, ease: Power4.easeOut }, del += 0.5)
	    .to("#offer3", 0.6, { left:0, ease: Power4.easeOut }, del += 0.5)


		
		
};
addListeners = function(e) {
	bgExit.addEventListener('touchEnd', bgExitHandler, false);
	bgExit.addEventListener('click', bgExitHandler, false);
};
bgExitHandler = function(e) {	
	Enabler.exit('handleclickthrough', window.clickTag);
};
window.onload = function (){
if (Enabler.isInitialized()) {
  enablerInitHandler();
} else {
	enablerInitHandler();
//  	Enabler.addEventListener(studio.events.StudioEvent.INIT, enablerInitHandler);
}
}